export * from './game-paginate-query.schema';
export * from './game-template-query.schema';
export * from './update-like-count.schema';
export * from './update-play-count.schema';
export * from './update-publish-status.schema';
