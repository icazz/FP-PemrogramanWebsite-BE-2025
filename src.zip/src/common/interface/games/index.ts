export * from './quiz.interface';
