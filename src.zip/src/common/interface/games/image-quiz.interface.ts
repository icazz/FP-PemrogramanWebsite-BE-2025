// src/common/interface/games/image-quiz.interface.ts

// Struktur jawaban di dalam database
export interface IImageQuizAnswer {
  answer_id: string; // UUID
  answer_text: string;
}

// Struktur pertanyaan di dalam database
export interface IImageQuizQuestion {
  question_id: string; // UUID
  question_text: string; // Judul pertanyaan (misal: "Tebak Gambar Apa Ini?")
  question_image_url: string; // Gambar yang akan dipotong-potong
  answers: IImageQuizAnswer[];
  correct_answer_id: string; // Kunci jawaban
}

// STRUKTUR BARU: Data Input Pertanyaan (Khusus untuk map dari Zod)
// Ini adalah data dari frontend sebelum diolah
export interface IImageQuizQuestionInput extends IImageQuizQuestion {
    // Tambahkan properti dari Zod yang HANYA ada di tahap INPUT:
    // question_image_array_index: number; 
}

// Struktur utama JSON yang disimpan di kolom game_json (Tabel Games)
export interface IImageQuizJson {
  // base_score: number; // Skor dasar jika benar
  // time_limit_seconds: number; // Waktu maksimal
  // tile_count: number; // Jumlah potongan gambar (misal: 9 atau 16)
  // reveal_interval: number; // Detik antar pembukaan potongan
  questions: IImageQuizQuestion[];
  is_question_randomized: boolean;
  is_answer_randomized: boolean;
}

// konfigurasi mutlak yang dikirim ke frontend
export interface IImageQuizConfig {
    time_limit_seconds: number;
    total_tiles: number;
    reveal_interval: number;
}